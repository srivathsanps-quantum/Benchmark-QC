"""Benchmark-QC: small helpers for QC benchmark Hamiltonians."""

__all__ = [
    "hamiltonian_test",
    "n2",
    "fes",
    "u2",
]
